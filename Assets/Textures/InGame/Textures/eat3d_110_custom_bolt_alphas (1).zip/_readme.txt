These are 110 Custom Bolt Alphas for use within sculpting applications.


/* **************************All Files********************************************************* */

	1. 110 Custom Bolt Alphas in .jpg format at a resolution of 512�.

/* ********************************************************************************************* */

Thanks for your support!
Eat3D


*Notice:
Eat 3D is not responsible for any damage caused by the files you downloaded. Please back up your work and exercise caution when going through our files. As described in the videos, be advised that many of our project files are very resource intensive so use at your own risk. 

Copyright 2012 Eat 3d, LLC All Rights Reserved. The Alphas contained within this zip file are provided at no cost for the community to use in their projects, including commercial and non-commercial use, on the condition that the Alphas themselves (the source files) are not externally redistributed, sold or repackaged in any manner.
i.e. You can use the Alphas for free, in any of your projects, as long as you don't redistribute, sell or repackage the source files.

The Greentooth logo is used with kind permission from Polycount (http://www.polycount.com/)

Thanks for your support!

Copyright 2012 All Rights Reserved - Eat 3D, LLC
www.eat3d.com - support@eat3d.com
Feed Your Brain!